# Guía de instalación y uso — Scrum-SDD v0.2.0

Esta guía explica cómo instalar el framework en un proyecto, iniciar un desarrollo nuevo, trabajar por historias y usarlo en un sistema existente. Los ejemplos usan **Claude Code** en macOS o Linux. En Windows, utiliza **Git Bash** para ejecutar `install.sh`.

## 1. Qué hace el framework

Scrum-SDD organiza el desarrollo en: **descubrimiento → requisitos DERCAS → diseño → arquitectura → backlog → configuración → implementación por historia → auditoría → release → operación**.

Los agentes generan artefactos, código y pruebas; el usuario revisa y aprueba las fases y acepta las historias. Las aprobaciones de fases caducan cuando cambia el archivo controlado por su hash. Esta restricción es de flujo de trabajo: **no autentica a una persona ni impide modificar el estado con acceso directo al sistema de archivos**.

## 2. Requisitos previos

- Python 3.9 o superior.
- Git y Bash.
- Al menos uno de los agentes: Claude Code, Codex, OpenCode, Antigravity o Pi, instalado y configurado.

Comprueba en la terminal:

```bash
python3 --version
git --version
bash --version
claude --version
```

Si utilizas otro agente, cambia la última línea por `codex --version`, `opencode --version` o el comando correspondiente.

## 3. Descargar y organizar carpetas

Descarga `scrum-sdd-v0.2.0.zip`, descomprímelo y coloca su carpeta `scrum-sdd` dentro de `~/proyectos/`:

```text
~/proyectos/
├── scrum-sdd/         # Framework (contiene install.sh)
└── mi-primera-app/    # Tu proyecto de software
```

Puedes crear los directorios desde una terminal:

```bash
mkdir -p ~/proyectos/mi-primera-app
```

> Si tienes `scrum-sdd` en otra ubicación, sustituye `~/proyectos/scrum-sdd` por su ruta real.

## 4. Instalar en tu proyecto

Desde una terminal:

```bash
bash "$HOME/proyectos/scrum-sdd/install.sh" "$HOME/proyectos/mi-primera-app"
```

El instalador crea `.claude/skills/`, `.agents/skills/`, envoltorios para OpenCode y Pi, `.framework/`, `docs/`, `specs/`, `src/`, `tests/` y `CLAUDE.md`. **No genera la aplicación todavía**; eso se hace en `/setup`.

Abre el directorio del proyecto con tu agente:

```bash
cd ~/proyectos/mi-primera-app
claude
```

Si ya tenías abierta la sesión del agente, ciérrala y vuelve a abrirla para cargar los skills.

**Importante:** a partir de este punto, los comandos con `/` se introducen **dentro del chat del agente**, no en Bash. En Codex se invocan mediante `$nombre` o el selector de skills.

## 5. Proyecto nuevo: recorrer las primeras seis fases

Ejemplo: un SaaS para gestionar citas en clínicas pequeñas. Ejecuta un skill por vez. Después de cada fase revisa los archivos generados y solamente entonces aprueba.

### Fase 0: descubrimiento

Dentro de Claude Code:

```text
/descubrir Quiero desarrollar un SaaS para que pequeñas clínicas gestionen citas, pacientes y recordatorios.
```

Revisa `docs/01-descubrimiento/` (visión, problema, Lean Canvas e hipótesis). Si estás de acuerdo:

```text
/aprobar descubrimiento --por "Tu Nombre"
```

### Fase 1: requisitos

```text
/dercas
```

Revisa `docs/02-requisitos/DERCAS.md`, incluidos RF, RNF, RN y CA:

```text
/aprobar requisitos --por "Tu Nombre"
```

### Fase 2: diseño

```text
/diseno
```

Revisa flujos, design system e inventario en `docs/03-diseno/`:

```text
/aprobar diseno --por "Tu Nombre"
```

### Fase 3: arquitectura

```text
/arquitectura
```

Revisa los diagramas, modelo de datos, API, seguridad y ADR en `docs/04-arquitectura/`. Aquí se decide y justifica el stack tecnológico.

```text
/aprobar arquitectura --por "Tu Nombre"
```

### Fase 4: planificación Scrum

```text
/backlog
```

Revisa `docs/05-scrum/`: épicas, historias, Definition of Ready, Definition of Done y Sprint 1.

```text
/aprobar backlog --por "Tu Nombre"
```

### Fase 5: entorno de desarrollo

```text
/setup
```

El agente genera `AGENTS.md` y configura estructura, herramientas, pruebas iniciales y CI según la arquitectura aprobada. Comprueba que el proyecto compile y pasen las verificaciones.

```text
/aprobar setup --por "Tu Nombre"
```

## 6. Implementar y aceptar historias

Para cada historia del sprint sigue este ciclo dentro del agente:

**1. Implementar una historia:**

```text
/implementar HU-001
```

El agente ejecuta Specify → Clarify → Plan → Tasks → Implement → Converge. Puede detenerse para resolver contradicciones o confirmar el plan. La implementación debe incluir pruebas que comprueben sus criterios de aceptación.

**2. Auditar de manera independiente:**

```text
/clear
/auditar HU-001
```

`/clear` es un comando de Claude Code para limpiar el contexto; como alternativa abre una sesión nueva. Corrige hallazgos críticos o altos y vuelve a auditar cuando corresponda.

**3. Aceptar la historia:**

Tras revisar y probar personalmente el resultado (UAT):

```text
/aceptar HU-001 --por "Tu Nombre"
```

Repite para `HU-002`, `HU-003`, etc. El agente **no debe registrar su propia aceptación**.

## 7. Release y operación

Cuando las historias del incremento estén aceptadas:

```text
/release
```

Revisa el Dockerfile, la configuración de CI/CD, el runbook, las notas de versión, secretos y entorno de destino. **El despliegue real depende de configurar infraestructura y credenciales; el framework no sustituye esa configuración.** La autorización de producción se realiza en la plataforma CI/CD.

Después de comprobar un despliegue en producción:

```text
/operar
```

Esto documenta SLO/SLA, registros, métricas, alertas y postmortems.

## 8. Consultar estado y trazabilidad

Dentro del agente:

```text
/estado
/trazabilidad
/trazabilidad HU-001
```

- `/estado`: muestra fases aprobadas, estados de historias y aprobaciones vencidas.
- `/trazabilidad`: valida asociaciones RF → CA → HU → pruebas.
- `/trazabilidad HU-001`: comprueba los criterios asociados a la historia indicada.

Si un control se bloquea, revisa el motivo que devuelve el agente y corrige la fase o evidencia correspondiente; no edites `docs/estado.json` manualmente.

## 9. Instalarlo en una aplicación existente

Desde Bash:

```bash
bash "$HOME/proyectos/scrum-sdd/install.sh" "$HOME/proyectos/mi-sistema-existente"
cd ~/proyectos/mi-sistema-existente
claude
```

Dentro del agente, usa el carril `feature` para comenzar a documentar el sistema y preparar su entorno:

```text
/dercas
/aprobar requisitos --por "Tu Nombre" --carril feature
/setup
/aprobar setup --por "Tu Nombre" --carril feature
```

Para una funcionalidad nueva, documenta el cambio, mantenlo en el backlog e impleméntalo por historia. Para una corrección urgente, usa el carril `hotfix`:

```text
/implementar HU-042 --carril hotfix
```

Un hotfix exige una prueba de regresión y auditoría.

## 10. Otros agentes

| Agente | Inicio habitual | Invocación de ejemplo |
| --- | --- | --- |
| Claude Code | `claude` | `/descubrir` |
| Codex | `codex` | `$descubrir` o selector de skills |
| OpenCode | `opencode` | `/descubrir` |
| Pi | `pi` | `/descubrir` o `/skill:descubrir` |
| Antigravity | Interfaz o CLI disponible | `/descubrir` (según integración) |

El instalador crea integraciones para estos agentes, pero la disponibilidad y las restricciones exactas dependen de sus versiones. Valida los comandos en tu instalación.

## 11. Ejecutar las pruebas del framework

Desde una **terminal**, no dentro del agente:

```bash
cd ~/proyectos/scrum-sdd
python3 -m unittest discover -s tests_framework -v
```

Estas son las pruebas del framework; además deben pasar las pruebas de cada aplicación creada con él.

## 12. Actualizar un proyecto

Descomprime la versión nueva del framework sobre su carpeta y ejecuta nuevamente:

```bash
bash "$HOME/proyectos/scrum-sdd/install.sh" "$HOME/proyectos/mi-primera-app"
```

Se vuelven a copiar scripts, skills y plantillas. El instalador conserva `docs/`, `specs/`, `AGENTS.md` y el código de tu aplicación. Antes de actualizar, guarda cambios en Git.

## 13. Problemas habituales

| Problema | Qué hacer |
| --- | --- |
| No aparece `/descubrir` | Reinicia el agente desde la carpeta del proyecto y verifica la instalación |
| Aparece `BLOQUEADO` | Ejecuta `/estado`; revisa aprobaciones y artefactos pendientes |
| Una aprobación caducó | Revisa los cambios del documento y vuelve a ejecutar `/aprobar` |
| Falla `/trazabilidad` | Corrige las referencias o pruebas y vuelve a ejecutar el comando |
| No se acepta `HU-001` | Completa implementación, auditoría y aceptación humana en orden |
| `/release` no avanza | Verifica historias aceptadas y controles del carril |

## 14. Resumen del flujo

```text
IDEA
  ↓ /descubrir      → /aprobar descubrimiento
  ↓ /dercas         → /aprobar requisitos
  ↓ /diseno         → /aprobar diseno
  ↓ /arquitectura   → /aprobar arquitectura
  ↓ /backlog        → /aprobar backlog
  ↓ /setup          → /aprobar setup
  ↓ /implementar HU-001
  ↓ /auditar HU-001 (contexto independiente)
  ↓ /aceptar HU-001 (persona, tras UAT)
  ↓ Repetir por historia
  ↓ /release        → autorización de producción en CI/CD
  ↓ /operar
```

**Nota de seguridad:** las restricciones de invocación humana de `/aprobar` y `/aceptar` funcionan como instrucciones/integraciones de los agentes, no como autenticación fuerte. No se debe presentar el archivo de estado local como prueba criptográfica de identidad.
