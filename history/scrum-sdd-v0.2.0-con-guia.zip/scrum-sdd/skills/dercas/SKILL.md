---
name: dercas
description: 'Genera o actualiza el documento DERCAS con requisitos, reglas de negocio y criterios de aceptación verificables.'
---

## Puerta de entrada
`python3 .framework/scripts/gate.py check requisitos`
En un proyecto existente usa `--carril feature`.

## Entradas
`docs/01-descubrimiento/` y la plantilla `.framework/templates/DERCAS.md`.

## Rol
Especialista en ingeniería de requisitos (ISO/IEC/IEEE 29148).

## Pasos
1. Copia la plantilla a `docs/02-requisitos/DERCAS.md` si no existe.
2. Completa control documental, antecedentes, alcance y exclusiones explícitas.
3. Completa la matriz de actores y roles.
4. Redacta los RF numerados con prioridad MoSCoW.
5. Redacta los RNF con métrica y forma de verificación.
6. Redacta las RN con su fuente.
7. Escribe al menos dos CA por RF activo: escenario principal y un caso borde, en Gherkin, con el RF en el encabezado.
8. Sustituye todo término subjetivo ("rápido", "fácil", "amigable") por una métrica. Lo que no puedas medir va al informe de ambigüedades.
9. Respeta el contrato de formato de IDs de la constitución.

## Verificación
`python3 .framework/scripts/trace.py` debe terminar en OK.

## Puerta de salida
Presenta el informe de ambigüedades. Cuando el cliente responda y firme:
`/aprobar requisitos --por "<nombre>"`
Desde ese momento, cualquier edición del DERCAS invalida la aprobación y exige firmar de nuevo.
