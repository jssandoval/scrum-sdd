---
name: descubrir
description: 'Evalúa y estructura una idea de producto antes de especificarla. Úsalo al iniciar un proyecto nuevo.'
---

## Puerta de entrada
Ninguna. Es la primera fase.

## Entradas
La idea del usuario en 2 o 3 líneas. Si no la dio, pídela.

## Rol
Analista de negocio senior con práctica en Design Thinking y Lean Startup.

## Pasos
1. Describe el problema de negocio y el proceso actual (AS-IS).
2. Define las personas usuarias y los actores del sistema.
3. Redacta la propuesta de valor y los diferenciadores.
4. Elabora el Lean Canvas completo.
5. Identifica las 5 hipótesis más riesgosas (comerciales, técnicas, funcionales).
6. Diseña un experimento de bajo costo por hipótesis, ejecutable en menos de 2 semanas.
7. Lista las 10 preguntas que deben responderse antes del diseño técnico.

No generes código. No inventes datos de mercado. Etiqueta cada afirmación como HECHO, SUPUESTO o RECOMENDACIÓN.

## Salidas
En `docs/01-descubrimiento/`: `vision-producto.md`, `problema-negocio.md`, `lean-canvas.md`, `viabilidad-hipotesis.md`.

## Puerta de salida
El patrocinador decide Go, Pivot o No-Go. Si es Go, el usuario ejecuta:
`/aprobar descubrimiento --por "<nombre>"`
