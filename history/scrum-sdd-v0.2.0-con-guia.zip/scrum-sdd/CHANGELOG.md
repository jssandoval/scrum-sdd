# Cambios

## 0.2.0 — 2026-11-14

- Conservados `/aprobar` y `/aceptar` como controles de aprobación humana explícitos, sin autenticación adicional.
- Documentadas las limitaciones de esa restricción cuando el usuario tiene acceso directo a Python o al repositorio.
- Validadas transiciones HU con especificación, trazabilidad e informe de auditoría aprobado.
- Rechazadas transiciones hacia atrás o saltos de estado.
- Validación de trazabilidad más estricta: CA declarados por HU y aserciones estructurales; no se equipara esa validación con ejecutar las pruebas.
- CI/CD falla si faltan scripts de despliegue reales; no más despliegues simulados mediante `echo`.
- Cinco pruebas automatizadas del framework.
- README actualizado.
